// src/secrets_template.h
// INSTRUCCIONES: Copia este archivo, renómbralo a "secrets.h" en la misma carpeta,
// y coloca tus credenciales reales. El archivo "secrets.h" está ignorado en Git.

#pragma once

// Credenciales de conexión inalámbrica (Solo se usan si USE_ETHERNET = false)
const char* WIFI_SSID = "TU_SSID_WIFI";
const char* WIFI_PASSWORD = "TU_PASSWORD_WIFI";

// Dirección IP física del servidor / autómata Modbus TCP de destino
const char* MODBUS_SERVER_IP = "192.168.1.100"; 
const uint16_t MODBUS_SERVER_PORT = 502; // Puerto estándar Modbus TCP
